#ifndef LIB_MAIN_H
#define LIB_MAIN_H

#include <stdio.h>

int saldo = 50000;

#endif // LIB_MAIN_H

