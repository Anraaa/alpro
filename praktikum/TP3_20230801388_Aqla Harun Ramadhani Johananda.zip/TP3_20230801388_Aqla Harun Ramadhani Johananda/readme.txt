bu maaf ini saya kirim ulang. buat yang deret mundur rumusnya saya sederhanakan lagi
