#include "stdio.h"

void celcius(int);
