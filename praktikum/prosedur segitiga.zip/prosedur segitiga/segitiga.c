#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "lib.segitiga.h"
#include "prc.segitiga.c"

void main(){
	
	int sm;
	
	segitiga(sm);
	
	getchar();
}
