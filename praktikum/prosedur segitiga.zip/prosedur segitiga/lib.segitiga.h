#include "stdio.h"

void segitiga(int);
